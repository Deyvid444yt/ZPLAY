module.exports = function () {
  return this.channel || ''
}
