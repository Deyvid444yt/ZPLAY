module.exports = function (channel) {
  return channel || null
}
