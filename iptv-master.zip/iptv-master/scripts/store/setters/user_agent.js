module.exports = function (user_agent) {
  return user_agent || null
}
